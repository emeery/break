const jwt = require('jsonwebtoken')
const User = require('../models/user')
const up = async(req, res, next) => {
    try {
        const token = req.headers.authorization.split(" ")[1]
            // const tk = req.header('Authorization').replace('Bearer ', '')
        const decoded = jwt.verify(token, 'la_llave')
        const user = await User.findOne({ _id: decoded.useride })
        if (!user) { throw new Error }
        req.userr = user;
        next()
    } catch (error) {
        res.status(401).json({ mensaje: "Aut Fallida" })
    }
}
module.exports = up
